var db = require('./database');

var POI = function() {};

POI.prototype.find = function(tableName, callback) {
  var sql = "SELECT * FROM " + tableName;
  // get a connection from the pool
  db.pool.getConnection(function(err, connection) {
    if(err) {
      return;
    }
    // make the query
    connection.query(sql, function(err, results) {
      if(err) {
        return;
      }
      callback(results);
    });
  });
};

module.exports = POI;
