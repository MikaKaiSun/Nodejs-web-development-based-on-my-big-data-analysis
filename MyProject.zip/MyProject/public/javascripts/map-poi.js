(function() {

  Mapster.MAP_OPTIONS.styles = [{"featureType":"landscape","stylers":[{"hue":"#FFBB00"},{"saturation":43.400000000000006},{"lightness":37.599999999999994},{"gamma":1}]},{"featureType":"road.highway","stylers":[{"hue":"#FFC200"},{"saturation":-61.8},{"lightness":45.599999999999994},{"gamma":1}]},{"featureType":"road.arterial","stylers":[{"hue":"#FF0300"},{"saturation":-100},{"lightness":51.19999999999999},{"gamma":1}]},{"featureType":"road.local","stylers":[{"hue":"#FF0300"},{"saturation":-100},{"lightness":52},{"gamma":1}]},{"featureType":"water","stylers":[{"hue":"#0078FF"},{"saturation":-13.200000000000003},{"lightness":2.4000000000000057},{"gamma":1}]},{"featureType":"poi","stylers":[{"hue":"#00FF6A"},{"saturation":-1.0989010989011234},{"lightness":11.200000000000017},{"gamma":1}]}];
  Mapster.MAP_OPTIONS.cluster = null;
  Mapster.MAP_OPTIONS.zoom = 16;
  // map options
  var options = Mapster.MAP_OPTIONS,
  // map id
  element = document.getElementById('map-poi'),
  // map
  map = Mapster.create(element, options);

  (function getPoiData() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/poiData', true);
    xhr.send();
    xhr.onreadystatechange = function() {
      if(xhr.readyState === 4 && xhr.status === 200) {
        var responseText =  JSON.parse(xhr.responseText);
        for(var i = 0; i < responseText.length; i++) {
          map.addMarker({
            lat: responseText[i].lat,
            lng: responseText[i].lng,
            // content: '<h2>POI名称：' + responseText[i].poi_name + '</h2>'
            content: '<table><tr><td>ID :</td><td>' + responseText[i].id + '</td></tr><tr><td>签到数 :</td><td>' + responseText[i].sign_number + '</td></tr><tr><td>类别 :</td><td>' + responseText[i].kind + '</td></tr><tr><td>POI名称 :</td><td>' + responseText[i].poi_name +'</td></tr><tr><td>地址 :</td><td>' + responseText[i].address + '</td></tr></table>'
          });
        }
      }
    };
  })();

}());
