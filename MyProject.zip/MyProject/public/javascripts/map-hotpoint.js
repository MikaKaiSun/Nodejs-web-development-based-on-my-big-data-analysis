(function() {
  // map options
  var options = Mapster.MAP_OPTIONS,
  // map id
  element = document.getElementById('map-hotpoint'),
  // map
  map = Mapster.create(element, options);

  // array include numbers in each cluster
  var clusterNumberData = [];

  // day and month
  var day = 0,
      month = 0;

  // date picker
  var datePickerOpts = {
		monthsShort: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
		weekdaysShort: ['日', '一', '二', '三', '四', '五', '六'],
		showMonthsShort: true,
		showWeekdaysShort: true,
		today: '',
		clear: '',
		close: '',
		min: new Date(2015,6,1),
		max: new Date(2015,10,26),
		firstDay: 1,
		formatSubmit: 'yyyy/mm/dd'
	};
  var $input = $('.datepicker').pickadate(datePickerOpts);
	var picker = $input.pickadate('picker');
	picker.on({
		set: function() {
			var date = new Date(picker.get());
	    month = date.getMonth() + 1;
      day = date.getDate();
      $('#selectedDate').html('2015 年 ' + month + ' 月 ' + day + ' 日');
      // init map.markers
      if(map.markers.items.length !== 0) {
        for(var i = 0; i < map.markers.items.length; i++) {
          map.markers.items[i].setMap(null);
        }
      }
      // init markerClusterer
      map.markerClusterer.clearMarkers();

			loadJSON('../data/' + month + '_' + day + '.json', function(res) {
        clusterNumberData = [];
				for(var i = 0; i < res.number; i++) {
          // push data to cluster number array
          clusterNumberData.push(res['cluster' + i].length);
          // draw markers
					res['cluster' + i].forEach(function(point) {
						map.addMarker({
							lat: parseFloat(point[0]),
							lng: parseFloat(point[1]),
							icon: {
								path: google.maps.SymbolPath.CIRCLE,
								scale: 6,
								strokeWeight: 2,
								fillColor: 'gold',
								fillOpacity: 0.7,
								strokeColor: 'gold'
							}
						});
					});
				}
			});
		}
	});

  var flag = true,
      modal2 = $('#modal2'),
      svg = $('.btnMenu svg'),
      btnMenu = $('.btnMenu'),
      myChart = $('#chart'),
      loading = $('#loading'),
      chart = undefined;
  btnMenu.on('click', function() {
    svg.css('fill', modal2.css('background-color'));
    var modal2Width = modal2.width(),
        viewportWidth = $('body').width();
    var right = (viewportWidth - modal2Width) / 2 - 50;
    if(flag === true) {
      flag = false;
      modal2.css('transform', 'scale(1)');
      modal2.css('opacity', '1');
      btnMenu.css('transform', 'scale(0.8) rotate(45deg)');
      btnMenu.css('right', right);
      btnMenu.css('top', '10%');
    } else if(flag !== true) {
      flag = true;
      modal2.css('transform', 'scale(0)');
      modal2.css('opacity', '0');
      btnMenu.css('transform', 'scale(1) rotate(90deg)');
      btnMenu.animate({
        top: '10px',
        right: '10px'
      });
    }
  });

  // generate click event
  var btnGenerate = $('.generate');
  btnGenerate.on('click', function() {
    var chartKind = $('#chart-kind').val();
    var chartTitle = $('#chart-wrap h2');
    chartTitle.html('加载中');
    $('#modal2 #progressbar').hide();
    $('#chart-wrap').show();
    btnMenu.css('right', 'calc(50% - 250px)');
    modal2.css('background-color', '#fff');
    svg.css('fill', '#fff');
    modal2.css('width', '400px');
    modal2.css('height', '400px');
    modal2.css('left', '50%');
    modal2.css('margin-left', '-200px');

    var data = {
      labels: [],
      datasets: [
        {
          data: [],
          backgroundColor: [],
          hoverBackgroundColor: []
        }
      ]
    };

    for(var i = 0; i < clusterNumberData.length; i++) {
      var color = getRandomColor();
      data.labels.push('cluster' + (i + 1));
      data.datasets[0].data.push(clusterNumberData[i]);
      data.datasets[0].backgroundColor.push(color);
      data.datasets[0].hoverBackgroundColor.push(color);
    }

    data.datasets[0].label = '';

    setTimeout(function(){
      if(chartKind === 'pie') {
        chartTitle.html('2015 年 ' + month + ' 月 ' + day + ' 日 ( 饼图 )');
        chart = new Chart(myChart, {
          type: 'pie',
          data: data
        });
      } else if(chartKind = 'bar') {
        chartTitle.html('2015 年 ' + month + ' 月 ' + day + ' 日 ( 柱状图 )');
        chart = new Chart(myChart, {
          type: 'bar',
          data: data
        });
      }
    }, 500);

  });

  // button back click event
  $('.fa-angle-left').on('click', function() {
    chart.destroy();
    $('#chart-wrap').hide();
    $('#modal2 #progressbar').show();
    btnMenu.css('right', 'calc(10% - 50px)');
    svg.css('fill', '#d33144');
    modal2.css('background-color', '#d33144');
    modal2.css('width', '80vw');
    modal2.css('height', '80vh');
    modal2.css('left', '10vw');
    modal2.css('margin-left', '0');
  });

  function getRandomColor() {
    var c = '#';
    var cArray = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'];
    for(var i = 0; i < 6; i++) {
      var cIndex = Math.round(Math.random() * 15);
      c += cArray[cIndex];
    }
    return c;
  }

}());
