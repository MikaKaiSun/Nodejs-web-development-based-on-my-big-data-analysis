$(function() {
  // btnMenu click event
  var flag = true,
      modal2 = $('#modal2'),
      svg = $('.btnMenu svg'),
      btnMenu = $('.btnMenu'),
      myChart = $('#chart'),
      loading = $('#loading'),
      chart = undefined;
  btnMenu.on('click', function() {
    svg.css('fill', modal2.css('background-color'));
    var modal2Width = modal2.width(),
        viewportWidth = $('body').width();
    var right = (viewportWidth - modal2Width) / 2 - 50;
    if(flag === true) {
      flag = false;
      modal2.css('transform', 'scale(1)');
      modal2.css('opacity', '1');
      btnMenu.css('transform', 'scale(0.8) rotate(45deg)');
      btnMenu.css('right', right);
      btnMenu.css('top', '10%');
    } else if(flag !== true) {
      flag = true;
      modal2.css('transform', 'scale(0)');
      modal2.css('opacity', '0');
      btnMenu.css('transform', 'scale(1) rotate(90deg)');
      btnMenu.animate({
        top: '10px',
        right: '10px'
      });
    }
  });

  // generate click event
  var btnGenerate = $('.generate');
  btnGenerate.on('click', function() {
    $('#modal2 #progressbar').hide();
    $('#chart-wrap').show();
    // loading.show();
    btnMenu.css('right', 'calc(50% - 250px)');
    modal2.css('background-color', '#fff');
    svg.css('fill', '#fff');
    modal2.css('width', '400px');
    modal2.css('height', '400px');
    modal2.css('left', '50%');
    modal2.css('margin-left', '-200px');



    var data = {
      labels: [
          "Red",
          "Green",
          "Yellow"
      ],
      datasets: [
        {
          data: [300, 50, 100],
          backgroundColor: [
            "#FF6384",
            "#36A2EB",
            "#FFCE56"
          ],
          hoverBackgroundColor: [
            "#FF6384",
            "#36A2EB",
            "#FFCE56"
          ]
        }]
    };

    setTimeout(function(){
      chart = new Chart(myChart, {
        type: 'pie',
        data: data
      });
    }, 500);

  });

  // button back click event
  $('.fa-angle-left').on('click', function() {
    btnMenu.css('right', 'calc(10% - 50px)');
    chart.destroy();
    $('#chart-wrap').hide();
    $('#modal2 #progressbar').show();
    modal2.css('background-color', '#d33144');
    svg.css('fill', '#d33144');
    modal2.css('width', '80vw');
    modal2.css('height', '80vh');
    modal2.css('left', '10vw');
    modal2.css('margin-left', '0');
  });
});
