(function() {

  Mapster.MAP_OPTIONS.styles = [{"stylers":[{"hue":"#2c3e50"},{"saturation":250}]},{"featureType":"road","elementType":"geometry","stylers":[{"lightness":50},{"visibility":"simplified"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]}];
  Mapster.MAP_OPTIONS.cluster = null;

  var options = Mapster.MAP_OPTIONS,

  element = document.getElementById('map-predict'),
  // map
  map = Mapster.create(element, options);

  var daySelect = document.getElementById('daySelect'),
      panel = daySelect.childNodes[0],
      menu = document.getElementById('menu'),
      btnMenu = document.getElementById('btnMenu'),
      day27 = document.getElementById('day27'),
      day28 = document.getElementById('day28'),
      day29 = document.getElementById('day29')
      day30 = document.getElementById('day30');
  // daySelect.addEventListener('click', function() {
  //   panel.style.opacity = '1';
  //   panel.style.top = '130%';
  // })
  menu.addEventListener('click', function() {
    if(btnMenu.className === 'active') {
      btnMenu.className = '';
      this.childNodes[1].style.transform = 'rotate(0)';
      this.childNodes[2].style.transform = 'rotate(0)';
      this.childNodes[3].style.opacity = '1';
      daySelect.style.right = '-150px';
    } else {
      btnMenu.className += 'active';
      this.childNodes[1].style.transform = 'rotate(43deg) translateY(-5px)';
      this.childNodes[2].style.transform = 'rotate(-43deg) translateY(5px)';
      this.childNodes[3].style.opacity = '0';
      daySelect.style.right = '0';
    }
  });

  day27.addEventListener('click', function() {
    if(map.markers.items.length !== 0) {
      for(var i = 0; i < map.markers.items.length; i++) {
        map.markers.items[i].setMap(null);
      }
    }
    loadJSON('../data/rp/' + 27 + '.json', function(res) {
      for(var i = 0; i < res.number; i++) {
        // draw markers
        res['cluster' + i].forEach(function(point) {
          map.addMarker({
            lat: parseFloat(point[0]),
            lng: parseFloat(point[1]),
            icon: {
              url: '../images/marker_3.svg'
            }
          });
        });
      }
    });
  });

  day28.addEventListener('click', function() {
    if(map.markers.items.length !== 0) {
      for(var i = 0; i < map.markers.items.length; i++) {
        map.markers.items[i].setMap(null);
      }
    }
    loadJSON('../data/rp/' + 28 + '.json', function(res) {
      for(var i = 0; i < res.number; i++) {
        // draw markers
        res['cluster' + i].forEach(function(point) {
          map.addMarker({
            lat: parseFloat(point[0]),
            lng: parseFloat(point[1]),
            icon: {
              url: '../images/marker_3.svg'
            }
          });
        });
      }
    });
  });

  day29.addEventListener('click', function() {
    if(map.markers.items.length !== 0) {
      for(var i = 0; i < map.markers.items.length; i++) {
        map.markers.items[i].setMap(null);
      }
    }
    loadJSON('../data/rp/' + 29 + '.json', function(res) {
      for(var i = 0; i < res.number; i++) {
        // draw markers
        res['cluster' + i].forEach(function(point) {
          map.addMarker({
            lat: parseFloat(point[0]),
            lng: parseFloat(point[1]),
            icon: {
              url: '../images/marker_3.svg'
            }
          });
        });
      }
    });
  });

  day30.addEventListener('click', function() {
    if(map.markers.items.length !== 0) {
      for(var i = 0; i < map.markers.items.length; i++) {
        map.markers.items[i].setMap(null);
      }
    }
    loadJSON('../data/rp/' + 30 + '.json', function(res) {
      for(var i = 0; i < res.number; i++) {
        // draw markers
        res['cluster' + i].forEach(function(point) {
          map.addMarker({
            lat: parseFloat(point[0]),
            lng: parseFloat(point[1]),
            icon: {
              url: '../images/marker_3.svg'
            }
          });
        });
      }
    });
  });

}())
