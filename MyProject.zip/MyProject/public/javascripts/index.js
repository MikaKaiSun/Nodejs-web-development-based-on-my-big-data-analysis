window.onload = function() {

  headerCheck();
  document.onscroll = function() { headerCheck(); };

  function headerCheck() {
    var header_copy = document.getElementById("header-copy");
    var y = document.documentElement.scrollTop | document.body.scrollTop;
    if(y >= 100) {
      header_copy.style.display = "block";
      header_copy.style.opacity = ".9";
    } else if(y < 100) {
      header_copy.style.display = "none";
    }
  }
};
