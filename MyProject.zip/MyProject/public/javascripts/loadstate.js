document.onreadystatechange = function() {

  switch (document.readyState) {
    case 'loading':
      // The document is still loading.
      break;
    case 'interactive':
      // The document has finished loading. We can now access the DOM elements.
      var modal = document.getElementById('modal');
      modal.style.display = 'block';
      break;
    case 'complete':
      // The page is fully loaded.
      var modal = document.getElementById('modal');

      modal.style.display = 'none';
      break;
  }

};
