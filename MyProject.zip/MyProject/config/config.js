module.exports = {
  mysql_dev: {
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'sina_hot',
    connectionLimit: 10,
    supportBigNumbers: true
  }
};
